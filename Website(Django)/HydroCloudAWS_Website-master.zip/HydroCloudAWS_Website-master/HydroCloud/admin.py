from django.contrib import admin
from .models import Plants, BlogPost
from .models import Greenhouses

# Register your models here.
admin.site.register(Plants)
admin.site.register(Greenhouses)
admin.site.register(BlogPost)

    
