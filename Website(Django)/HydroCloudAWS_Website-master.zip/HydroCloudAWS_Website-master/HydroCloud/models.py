from django.contrib.auth.base_user import BaseUserManager
from django.db import models
from django.contrib.auth.models import User, AbstractUser


# Create your models here.


class Greenhouses(models.Model):
    greenhouseid = models.AutoField(db_column='GreenhouseID', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=255)  # Field name made lowercase.
    location = models.CharField(db_column='Location', max_length=255)  # Field name made lowercase.
    numberofsystems = models.IntegerField(db_column='NumberOfSystems', default=0)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Greenhouses'


class Growthstages(models.Model):
    growthstagename = models.CharField(db_column='GrowthStageName', primary_key=True, max_length=255)  # Field name made lowercase.
    growthstagedescription = models.TextField(db_column='GrowthStageDescription', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'GrowthStages'


class Plantspecies(models.Model):
    plantspeciesname = models.CharField(db_column='PlantSpeciesName', primary_key=True, max_length=255)  # Field name made lowercase.
    plantspeciesdescription = models.TextField(db_column='PlantSpeciesDescription')  # Field name made lowercase.
    notes = models.TextField(db_column='Notes', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'PlantSpecies'


class Plants(models.Model):
    plantsid = models.AutoField(db_column='PlantsID', primary_key=True)  # Field name made lowercase.
    plantspeciesname = models.ForeignKey(Plantspecies, models.DO_NOTHING, db_column='PlantSpeciesName')  # Field name made lowercase.
    comments = models.TextField(db_column='Comments', blank=True, null=True)  # Field name made lowercase.
    ideal_phvaluemin = models.DecimalField(db_column='Ideal_PHValueMin', max_digits=10, decimal_places=5)
    ideal_phvaluemax = models.DecimalField(db_column='Ideal_PHValueMax', max_digits=10, decimal_places=5)
    ideal_ecvaluemin_ms_cm = models.DecimalField(db_column='Ideal_ECValueMin_mS_cm', max_digits=10, decimal_places=5)
    ideal_ecvaluemax_ms_cm = models.DecimalField(db_column='Ideal_ECValueMax_mS_cm', max_digits=10, decimal_places=5)
    ideal_tdsvaluemin = models.DecimalField(db_column='Ideal_TDSValueMin', max_digits=10, decimal_places=5)
    ideal_tdsvaluemax = models.DecimalField(db_column='Ideal_TDSValueMax', max_digits=10, decimal_places=5)
    ideal_waterlevelmin = models.DecimalField(db_column='Ideal_WaterLevelMin', max_digits=10, decimal_places=5, null=True, blank=True)
    ideal_waterlevelmax = models.DecimalField(db_column='Ideal_WaterLevelMax', max_digits=10, decimal_places=5, null=True, blank=True)
    ideal_watertemperaturemin = models.DecimalField(db_column='Ideal_WaterTemperatureMin', max_digits=10, decimal_places=5)
    ideal_watertemperaturemax = models.DecimalField(db_column='Ideal_WaterTemperatureMax', max_digits=10, decimal_places=5)
    ideal_wateroxygenLevelmin_mg_l = models.DecimalField(db_column='Ideal_WaterOxygenLevelMin_mg_l', max_digits=10, decimal_places=5)
    ideal_wateroxygenLevelmax_mg_l = models.DecimalField(db_column='Ideal_WaterOxygenLevelMax_mg_l', max_digits=10, decimal_places=5)
    ideal_lightdurationmin = models.DecimalField(db_column='Ideal_LightDurationMin', max_digits=10, decimal_places=5)
    ideal_lightdurationmax = models.DecimalField(db_column='Ideal_LightDurationMax', max_digits=10, decimal_places=5)
    ideal_lightintensitymin_nm = models.DecimalField(db_column='Ideal_LightIntensityMin_nm', max_digits=10, decimal_places=5)
    ideal_lightintensitymax_nm = models.DecimalField(db_column='Ideal_LightIntensityMax_nm', max_digits=10, decimal_places=5)
    ideal_airoxygenlevelmin = models.DecimalField(db_column='Ideal_AirOxygenLevelMin', max_digits=10, decimal_places=5, null=True, blank=True)
    ideal_airoxygenlevelmax = models.DecimalField(db_column='Ideal_AirOxygenLevelMax', max_digits=10, decimal_places=5, null=True, blank=True)
    ideal_airco2levelmin = models.DecimalField(db_column='Ideal_AirCO2LevelMin', max_digits=10, decimal_places=5, null=True, blank=True)
    ideal_airco2levelmax = models.DecimalField(db_column='Ideal_AirCO2LevelMax', max_digits=10, decimal_places=5, null=True, blank=True)
    ideal_airtemperaturedaymin = models.DecimalField(db_column='Ideal_AirTemperatureDayMin', max_digits=10, decimal_places=5)
    ideal_airtemperaturedaymax = models.DecimalField(db_column='Ideal_AirTemperatureDayMax', max_digits=10, decimal_places=5)
    ideal_airtemperaturenightmin = models.DecimalField(db_column='Ideal_AirTemperatureNightMin', max_digits=10, decimal_places=5)
    ideal_airtemperaturenightmax = models.DecimalField(db_column='Ideal_AirTemperatureNightMax', max_digits=10, decimal_places=5)
    ideal_humiditymin = models.DecimalField(db_column='Ideal_HumidityMin', max_digits=10, decimal_places=5)
    ideal_humiditymax = models.DecimalField(db_column='Ideal_HumidityMax', max_digits=10, decimal_places=5)
    ideal_wn_nitrogen = models.DecimalField(db_column='Ideal_WN_Nitrogen', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ideal_wn_phosphor = models.DecimalField(db_column='Ideal_WN_Phosphor', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ideal_wn_potassium = models.DecimalField(db_column='Ideal_WN_Potassium', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ideal_wn_sulfur = models.DecimalField(db_column='Ideal_WN_Sulfur', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ideal_wn_calcium = models.DecimalField(db_column='Ideal_WN_Calcium', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ideal_wn_magnesium = models.DecimalField(db_column='Ideal_WN_Magnesium', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ideal_wn_iron = models.DecimalField(db_column='Ideal_WN_Iron', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ideal_wn_manganese = models.DecimalField(db_column='Ideal_WN_Manganese', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ideal_wn_boron = models.DecimalField(db_column='Ideal_WN_Boron', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ideal_wn_copper = models.DecimalField(db_column='Ideal_WN_Copper', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ideal_wn_zinc = models.DecimalField(db_column='Ideal_WN_Zinc', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ideal_wn_molybdenum = models.DecimalField(db_column='Ideal_WN_Molybdenum', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    plants_name = models.CharField(db_column='PlantName', max_length=100)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Plants'


class Sensortypes(models.Model):
    sensortypeid = models.AutoField(db_column='SensorTypeID', primary_key=True)  # Field name made lowercase.
    sensortype = models.CharField(db_column='SensorType', max_length=255)  # Field name made lowercase.
    sensortypesdescription = models.TextField(db_column='SensorTypesDescription')  # Field name made lowercase.
    unit = models.CharField(db_column='Unit', max_length=50)  # Field name made lowercase.
    system_valuename = models.CharField(db_column='System_ValueName', max_length=50)  # Field name made lowercase.
    difference_warning = models.DecimalField(db_column='Difference_Warning', max_digits=10, decimal_places=5)  # Field name made lowercase.
    difference_critical = models.DecimalField(db_column='Difference_Critical', max_digits=10, decimal_places=5)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'SensorTypes'


class Subscriptions(models.Model):
    subscriptiontype = models.CharField(db_column='SubscriptionType', primary_key=True, max_length=100)  # Field name made lowercase.
    price = models.DecimalField(db_column='Price', max_digits=10, decimal_places=2)  # Field name made lowercase.
    durationmonth = models.IntegerField(db_column='DurationMonth')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Subscriptions'


class Systems(models.Model):
    systemid = models.AutoField(db_column='SystemID', primary_key=True)  # Field name made lowercase.
    greenhouseid = models.ForeignKey(Greenhouses, models.DO_NOTHING, db_column='GreenhouseID')  # Field name made lowercase.
    systemname = models.CharField(db_column='SystemName', max_length=255)  # Field name made lowercase.
    creationdate = models.DateField(db_column='CreationDate', blank=True, auto_now_add=True)  # Field name made lowercase.
    changedate = models.DateTimeField(db_column='ChangeDate', blank=True, auto_now_add=True)  # Field name made lowercase.
    comments = models.TextField(db_column='Comments', blank=True, null=True)  # Field name made lowercase.
    growthstagename = models.ForeignKey(Growthstages, models.DO_NOTHING, db_column='GrowthStageName')  # Field name made lowercase.
    readymadefertilizer = models.BooleanField(db_column='ReadyMadeFertilizer')  # Field name made lowercase.
    phvalue = models.DecimalField(db_column='PHValue', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    ecvalue = models.DecimalField(db_column='ECValue', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    tdsvalue = models.DecimalField(db_column='TDSValue', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    waterlevel = models.DecimalField(db_column='WaterLevel', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    watertemperature = models.DecimalField(db_column='WaterTemperature', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wateroxygenlevel = models.DecimalField(db_column='WaterOxygenLevel', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    lightduration = models.DecimalField(db_column='LightDuration', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    lightintensity = models.DecimalField(db_column='LightIntensity', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    airoxygenlevel = models.DecimalField(db_column='AirOxygenLevel', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    airco2level = models.DecimalField(db_column='AirCO2Level', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    airtemperatureday = models.DecimalField(db_column='AirTemperatureDay', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    airtemperaturenight = models.DecimalField(db_column='AirTemperatureNight', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    humidity = models.DecimalField(db_column='Humidity', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_nitrogen = models.DecimalField(db_column='WN_Nitrogen', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_phosphor = models.DecimalField(db_column='WN_Phosphor', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_potassium = models.DecimalField(db_column='WN_Potassium', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_sulfur = models.DecimalField(db_column='WN_Sulfur', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_calcium = models.DecimalField(db_column='WN_Calcium', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_magnesium = models.DecimalField(db_column='WN_Magnesium', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_iron = models.DecimalField(db_column='WN_Iron', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_manganese = models.DecimalField(db_column='WN_Manganese', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_boron = models.DecimalField(db_column='WN_Boron', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_copper = models.DecimalField(db_column='WN_Copper', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_zinc = models.DecimalField(db_column='WN_Zinc', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    wn_molybdenum = models.DecimalField(db_column='WN_Molybdenum', max_digits=10, decimal_places=5, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Systems'


class Systemsplantsassignment(models.Model):
    systemid = models.OneToOneField(Systems, models.DO_NOTHING, db_column='SystemID', primary_key=True)  # Field name made lowercase. The composite primary key (SystemID, PlantsID) found, that is not supported. The first column is selected.
    plantsid = models.ForeignKey(Plants, models.DO_NOTHING, db_column='PlantsID')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'SystemsPlantsAssignment'
        unique_together = (('systemid', 'plantsid'),)


class Devices(models.Model):
    class StatusTypes(models.TextChoices):
        ACTIVE = 'active'
        INACTIVE = 'inactive'

    class TypeTypes(models.TextChoices):
        PUMP = 'Pump'
        SENSOR = 'Sensor'

    deviceid = models.AutoField(db_column='DeviceID', primary_key=True)  # Field name made lowercase.
    sensortypeid = models.ForeignKey(Sensortypes, models.DO_NOTHING, db_column='SensorTypeID')  # Field name made lowercase.
    systemid = models.ForeignKey(Systems, models.DO_NOTHING, db_column='SystemID')  # Field name made lowercase.
    devicename = models.CharField(db_column='DeviceName', max_length=255)  # Field name made lowercase.
    devicedescription = models.TextField(db_column='DeviceDescription', blank=True, null=True)  # Field name made lowercase.
    status = models.CharField(db_column='Status', choices=StatusTypes.choices, default=StatusTypes.ACTIVE, max_length=12)  # Field name made lowercase.
    type = models.CharField(db_column='Type', choices=TypeTypes.choices, default=TypeTypes.SENSOR, max_length=12)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Devices'


class Historydevicedata(models.Model):
    historydevicedataid = models.AutoField(db_column='HistoryDeviceDataID', primary_key=True)  # Field name made lowercase.
    deviceid = models.ForeignKey(Devices, models.DO_NOTHING, db_column='DeviceID')  # Field name made lowercase.
    date = models.DateField(db_column='Date')  # Field name made lowercase.
    time = models.TimeField(db_column='Time')  # Field name made lowercase.
    measurement = models.DecimalField(db_column='Measurement', max_digits=10, decimal_places=5)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'HistoryDeviceData'


class Media(models.Model):
    class MediaTypeTypes(models.TextChoices):
        IMAGE = 'Bild'
        VIDEO = 'Video'
        AUDIO = 'Audio'

    mediaid = models.AutoField(db_column='MediaID', primary_key=True)  # Field name made lowercase.
    mediatype = models.CharField(db_column='MediaType', choices=MediaTypeTypes.choices, max_length=12)  # Field name made lowercase.
    medianame = models.CharField(db_column='MediaName', max_length=255)  # Field name made lowercase.
    mediadescription = models.TextField(db_column='MediaDescription', blank=True, null=True)  # Field name made lowercase.
    mediaurl = models.CharField(db_column='MediaURL', max_length=1000)  # Field name made lowercase.
    mediathumbnailurl = models.CharField(db_column='MediaThumbnailURL', max_length=1000)  # Field name made lowercase.
    systemid = models.ForeignKey(Systems, models.DO_NOTHING, db_column='SystemID', blank=True, null=True)  # Field name made lowercase.
    plantsid = models.ForeignKey(Plants, models.DO_NOTHING, db_column='PlantsID', blank=True, null=True)  # Field name made lowercase.
    greenhouseid = models.ForeignKey(Greenhouses, models.DO_NOTHING, db_column='GreenhouseID', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Media'


class Taxclasses(models.Model):
    taxclassid = models.AutoField(db_column='TaxClassID', primary_key=True)  # Field name made lowercase.
    taxclass = models.CharField(db_column='TaxClass', max_length=255)  # Field name made lowercase.
    taxrate = models.DecimalField(db_column='TaxRate', max_digits=10, decimal_places=5)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'TaxClasses'


class Usersubscriptions(models.Model):
    userid = models.OneToOneField(User, models.DO_NOTHING, db_column='UserID', primary_key=True)  # Field name made lowercase. The composite primary key (UserID, SubscriptionType) found, that is not supported. The first column is selected.
    subscriptiontype = models.ForeignKey(Subscriptions, models.DO_NOTHING, db_column='SubscriptionType')  # Field name made lowercase.
    startdate = models.DateField(db_column='StartDate')  # Field name made lowercase.
    enddate = models.DateField(db_column='EndDate')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'UserSubscriptions'
        unique_together = (('userid', 'subscriptiontype'),)


class Bugreports(models.Model):
    class PriorityTypes(models.TextChoices):
        LOW = 'low'
        MEDIUM = 'medium'
        HIGH = 'high'

    class StatusTypes(models.TextChoices):
        OPEN = 'open'
        INPROGRESS = 'in progress'
        CLOSED = 'closed'

    bugreportid = models.AutoField(db_column='BugreportID', primary_key=True)  # Field name made lowercase.
    userid = models.ForeignKey(User, models.DO_NOTHING, db_column='UserID')  # Field name made lowercase.
    description = models.TextField(db_column='Description')  # Field name made lowercase.
    createdat = models.DateTimeField(db_column='CreatedAt')  # Field name made lowercase.
    priority = models.CharField(db_column='Priority', choices=PriorityTypes.choices, max_length=12)  # Field name made lowercase.
    status = models.CharField(db_column='Status', choices=StatusTypes.choices, default=StatusTypes.OPEN, max_length=12)  # Field name made lowercase.
    currentprocessorid = models.IntegerField(db_column='CurrentProcessorID', blank=True, null=True)  # Field name made lowercase.
    lastupdatedat = models.DateTimeField(db_column='LastUpdatedAt', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Bugreports'


class Contactinformation(models.Model):
    class ContactTypes(models.TextChoices):
        EMAIL = 'Email'
        PHONE = 'Telefon'
        ADDRESS = 'Adress'

    contactid = models.AutoField(db_column='ContactID', primary_key=True)  # Field name made lowercase.
    userid = models.ForeignKey(User, models.DO_NOTHING, db_column='UserID')  # Field name made lowercase.
    contacttype = models.CharField(db_column='ContactType', choices=ContactTypes.choices, max_length=12)  # Field name made lowercase.
    contactvalue = models.TextField(db_column='ContactValue', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'ContactInformation'


class Transactions(models.Model):
    class StatusTypes(models.TextChoices):
        PENDING = 'pending'
        COMPLETED = 'completed'
        FAILED = 'failed'
    transactionsid = models.AutoField(db_column='TransactionsID', primary_key=True)  # Field name made lowercase.
    userid = models.ForeignKey(User, models.DO_NOTHING, db_column='UserID')  # Field name made lowercase.
    date = models.DateField(db_column='Date')  # Field name made lowercase.
    totalamount = models.DecimalField(db_column='TotalAmount', max_digits=10, decimal_places=2)  # Field name made lowercase.
    status = models.CharField(db_column='Status', choices=StatusTypes.choices, default=StatusTypes.PENDING, max_length=12, blank=True, null=True)  # Field name made lowercase.
    externaltransactionid = models.CharField(db_column='ExternalTransactionID', max_length=255)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Transactions'


class Items(models.Model):
    itemid = models.AutoField(db_column='ItemID', primary_key=True)  # Field name made lowercase.
    itemname = models.CharField(db_column='ItemName', max_length=255)  # Field name made lowercase.
    description = models.TextField(db_column='Description', blank=True, null=True)  # Field name made lowercase.
    manufacturer = models.CharField(db_column='Manufacturer', max_length=255, blank=True, null=True)  # Field name made lowercase.
    category = models.CharField(db_column='Category', max_length=100, blank=True, null=True)  # Field name made lowercase.
    price = models.DecimalField(db_column='Price', max_digits=10, decimal_places=2)  # Field name made lowercase.
    taxclassid = models.ForeignKey(Taxclasses, models.DO_NOTHING, db_column='TaxClassID')  # Field name made lowercase.
    discountinpercent = models.DecimalField(db_column='DiscountInPercent', max_digits=10, decimal_places=5)  # Field name made lowercase.
    contentamount = models.DecimalField(db_column='ContentAmount', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    unit = models.CharField(db_column='Unit', max_length=50, blank=True, null=True)  # Field name made lowercase.
    ean = models.CharField(db_column='EAN', max_length=13, blank=True, null=True)  # Field name made lowercase.
    upc = models.CharField(db_column='UPC', max_length=12, blank=True, null=True)  # Field name made lowercase.
    isbn = models.CharField(db_column='ISBN', max_length=13, blank=True, null=True)  # Field name made lowercase.
    stock = models.IntegerField(db_column='Stock', blank=True, null=True)  # Field name made lowercase.
    weight = models.DecimalField(db_column='Weight', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    dimensionlength = models.DecimalField(db_column='DimensionLength', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    dimensionwidth = models.DecimalField(db_column='DimensionWidth', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    dimensionheight = models.DecimalField(db_column='DimensionHeight', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    metatitle = models.CharField(db_column='MetaTitle', max_length=255, blank=True, null=True)  # Field name made lowercase.
    metadescription = models.TextField(db_column='MetaDescription', blank=True, null=True)  # Field name made lowercase.
    urlslug = models.CharField(db_column='URLSlug', max_length=255, blank=True, null=True)  # Field name made lowercase.
    active = models.BooleanField(db_column='Active')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Items'


class Itemimages(models.Model):
    imageid = models.AutoField(db_column='ImageID', primary_key=True)  # Field name made lowercase.
    itemid = models.ForeignKey(Items, models.DO_NOTHING, db_column='ItemID')  # Field name made lowercase.
    imageurl = models.CharField(db_column='ImageURL', max_length=255)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'ItemImages'


class Notificationpreferences(models.Model):
    class PreferenceTypes(models.TextChoices):
        EMAIL = 'Email'
        SMS = 'SMS'
        APP = 'App'
    preferenceid = models.AutoField(db_column='PreferenceID', primary_key=True)  # Field name made lowercase.
    userid = models.ForeignKey(User, models.DO_NOTHING, db_column='UserID')  # Field name made lowercase.
    preferencetype = models.CharField(db_column='PreferenceType', choices=PreferenceTypes.choices, default=PreferenceTypes.EMAIL, max_length=6)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'NotificationPreferences'


class Passwordresettokens(models.Model):
    class StatusTypes(models.TextChoices):
        ACTIVE = 'Active'
        USED = 'Used'
        EXPIRED = 'Expired'
    tokenid = models.AutoField(db_column='TokenID', primary_key=True)  # Field name made lowercase.
    userid = models.ForeignKey(User, models.DO_NOTHING, db_column='UserID')  # Field name made lowercase.
    token = models.CharField(db_column='Token', max_length=255)  # Field name made lowercase.
    createdat = models.DateTimeField(db_column='CreatedAt', blank=True, null=True)  # Field name made lowercase.
    status = models.CharField(db_column='Status', choices=StatusTypes.choices, blank=True, null=True, max_length=8)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'PasswordResetTokens'


class Transactionitem(models.Model):
    transactionitemid = models.AutoField(db_column='TransactionItemID', primary_key=True)  # Field name made lowercase.
    transactionid = models.ForeignKey(Transactions, models.DO_NOTHING, db_column='TransactionID')  # Field name made lowercase.
    itemid = models.ForeignKey(Items, models.DO_NOTHING, db_column='ItemID')  # Field name made lowercase.
    quantity = models.IntegerField(db_column='Quantity')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'TransactionItem'


class Greenhouseuserassignment(models.Model):
    userid = models.OneToOneField(User, models.DO_NOTHING, db_column='UserID', primary_key=True)  # Field name made lowercase. The composite primary key (UserID, GreenhouseID) found, that is not supported. The first column is selected.
    greenhouseid = models.ForeignKey(Greenhouses, models.DO_NOTHING, db_column='GreenhouseID')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'GreenhouseUserAssignment'
        unique_together = (('userid', 'greenhouseid'),)


class BlogCategory(models.Model):
    name = models.CharField(max_length=255, unique=False, null=False)
    description = models.TextField(null=True, blank=True)

    class Meta:
        managed = False
        db_table = 'BlogCategory'

    def __str__(self):
        return self.name

class BlogPost(models.Model):
    title = models.CharField(max_length=255, null=False)
    subtitle = models.CharField(max_length=255, null=True, blank=True)
    authors = models.CharField(max_length=200, null=False)
    publication_date = models.DateField(auto_now_add=True)  # Setzt das aktuelle Datum als Standardwert beim Erstellen
    content = models.TextField(null=False)
    preview_image = models.ImageField(upload_to='img/blog/', null=True, blank=True)

    class Meta:
        managed = False
        db_table = 'BlogPost'


class BlogPostCategory(models.Model):
    blog_post = models.ForeignKey(BlogPost, on_delete=models.CASCADE)
    category = models.ForeignKey(BlogCategory, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'BlogPostCategory'


