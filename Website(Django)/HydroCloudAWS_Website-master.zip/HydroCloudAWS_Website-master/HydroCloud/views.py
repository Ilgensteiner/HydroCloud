import json

from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.http import HttpResponseRedirect, Http404, JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.db import connection
from django import forms

from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt

from HydroCloud.models import Greenhouseuserassignment, Greenhouses, Systems, Growthstages, Systemsplantsassignment, \
    Devices, Historydevicedata, Sensortypes, Plants
from HydroCloud.services import get_latest_sensor_data_for_system

# blog related
from django.views.generic import ListView, DetailView
from HydroCloud.models import BlogPost, BlogCategory, BlogPostCategory


def is_admin(user):
    return user.is_superuser


# blog related

def blog(request):
    return render(request, 'blog.html')


class blogView(ListView):
    model = BlogPost
    template_name = 'blog.html'
    context_object_name = 'blog'

    def get_context_data(self, **kwargs):
        context = {'blog': BlogPost.objects.all().order_by('-publication_date')}
        context[
            'blog_post_category'] = BlogPostCategory.objects.all()  # Daten aus der zweiten Tabelle abrufen und dem Kontext hinzufügen
        context[
            'blog_category'] = BlogCategory.objects.all()  # Daten aus der zweiten Tabelle abrufen und dem Kontext hinzufügen
        return context



def post(request):
    return render(request, 'post.html')


class postView(DetailView):
    model = BlogPost
    template_name = 'post.html'
    context_object_name = 'blog_post'


class BlogPostForm(forms.ModelForm):
    class Meta:
        model = BlogPost
        fields = ['title', 'subtitle', 'authors', 'content', 'preview_image']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'mb-3'}),
            'subtitle': forms.TextInput(attrs={'class': 'mb-3'}),
            'authors': forms.TextInput(attrs={'class': 'mb-3'}),
            'content': forms.Textarea(attrs={'class': 'mb-3'}),
            'preview_image': forms.ClearableFileInput(attrs={'class': 'mb-3'}),
        }

class BlogPostCategoryForm(forms.ModelForm):
    class Meta:
        model = BlogPostCategory
        fields = ['category']
        widgets = {
            'category': forms.Select(attrs={'class': 'form-select-button full-width'}),
        }

# admin related
@login_required
@user_passes_test(is_admin)
def create_blog_post(request):
    if request.method == 'POST':
        post_form = BlogPostForm(request.POST, request.FILES)
        category_form = BlogPostCategoryForm(request.POST)

        if post_form.is_valid() and category_form.is_valid():
            # Speichere zuerst den BlogPost
            new_post = post_form.save()

            # Jetzt verknüpfe die Kategorie mit dem BlogPost
            new_post_category = category_form.save(commit=False)
            new_post_category.blog_post = new_post
            new_post_category.save()

            return redirect('create_blog_post')
    else:
        post_form = BlogPostForm()
        category_form = BlogPostCategoryForm()

    return render(request, 'create_blog_post.html', {
        'post_form': post_form,
        'category_form': category_form
    })

@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(login_required, name='dispatch')
@method_decorator(user_passes_test(is_admin), name='dispatch')
def create_blog_post_api(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            post_form = BlogPostForm(data)
            category_form = BlogPostCategoryForm(data)

            if post_form.is_valid() and category_form.is_valid():
                # Speichere zuerst den BlogPost
                new_post = post_form.save()

                # Jetzt verknüpfe die Kategorie mit dem BlogPost
                new_post_category = category_form.save(commit=False)
                new_post_category.blog_post = new_post
                new_post_category.save()

                return JsonResponse({'status': 'success', 'post_id': new_post.id}, status=201)
            else:
                return JsonResponse({'status': 'error', 'errors': post_form.errors + category_form.errors}, status=400)
        except json.JSONDecodeError:
            return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)
    return JsonResponse({'status': 'error', 'message': 'Invalid method'}, status=405)

# Blog related end


def calculate_System(selected_system, plantsInSystem_objects):
    ideal_values = {
        "Ideal_PHValueMin": None,
        "Ideal_PHValueMax": None,
        "Ideal_ECValueMin_mS_cm": None,
        "Ideal_ECValueMax_mS_cm": None,
        "Ideal_TDSValueMin": None,
        "Ideal_TDSValueMax": None,
        "Ideal_WaterLevelMin": None,
        "Ideal_WaterLevelMax": None,
        "Ideal_WaterTemperatureMin": None,
        "Ideal_WaterTemperatureMax": None,
        "Ideal_WaterOxygenLevelMin_mg_l": None,
        "Ideal_WaterOxygenLevelMax_mg_l": None,
        "Ideal_LightDurationMin": None,
        "Ideal_LightDurationMax": None,
        "Ideal_LightIntensityMin_nm": None,
        "Ideal_LightIntensityMax_nm": None,
        "Ideal_AirOxygenLevelMin": None,
        "Ideal_AirOxygenLevelMax": None,
        "Ideal_AirCO2LevelMin": None,
        "Ideal_AirCO2LevelMax": None,
        "Ideal_AirTemperatureDayMin": None,
        "Ideal_AirTemperatureDayMax": None,
        "Ideal_AirTemperatureNightMin": None,
        "Ideal_AirTemperatureNightMax": None,
        "Ideal_HumidityMin": None,
        "Ideal_HumidityMax": None,
        "Ideal_WN_Nitrogen": None,
        "Ideal_WN_Phosphor": None,
        "Ideal_WN_Potassium": None,
        "Ideal_WN_Sulfur": None,
        "Ideal_WN_Calcium": None,
        "Ideal_WN_Magnesium": None,
        "Ideal_WN_Iron": None,
        "Ideal_WN_Manganese": None,
        "Ideal_WN_Boron": None,
        "Ideal_WN_Copper": None,
        "Ideal_WN_Zinc": None,
        "Ideal_WN_Molybdenum": None,
    }

    for plant in plantsInSystem_objects:
        if plant.ideal_phvaluemin is not None and (
                ideal_values["Ideal_PHValueMin"] is None or plant.ideal_phvaluemin > ideal_values["Ideal_PHValueMin"]):
            ideal_values["Ideal_PHValueMin"] = plant.ideal_phvaluemin
        if plant.ideal_phvaluemax is not None and (
                ideal_values["Ideal_PHValueMax"] is None or plant.ideal_phvaluemax < ideal_values["Ideal_PHValueMax"]):
            ideal_values["Ideal_PHValueMax"] = plant.ideal_phvaluemax
        if plant.ideal_ecvaluemin_ms_cm is not None and (
                ideal_values["Ideal_ECValueMin_mS_cm"] is None or plant.ideal_ecvaluemin_ms_cm > ideal_values[
            "Ideal_ECValueMin_mS_cm"]):
            ideal_values["Ideal_ECValueMin_mS_cm"] = plant.ideal_ecvaluemin_ms_cm
        if plant.ideal_ecvaluemax_ms_cm is not None and (
                ideal_values["Ideal_ECValueMax_mS_cm"] is None or plant.ideal_ecvaluemax_ms_cm < ideal_values[
            "Ideal_ECValueMax_mS_cm"]):
            ideal_values["Ideal_ECValueMax_mS_cm"] = plant.ideal_ecvaluemax_ms_cm
        if plant.ideal_tdsvaluemin is not None and (
                ideal_values["Ideal_TDSValueMin"] is None or plant.ideal_tdsvaluemin > ideal_values[
            "Ideal_TDSValueMin"]):
            ideal_values["Ideal_TDSValueMin"] = plant.ideal_tdsvaluemin
        if plant.ideal_tdsvaluemax is not None and (
                ideal_values["Ideal_TDSValueMax"] is None or plant.ideal_tdsvaluemax < ideal_values[
            "Ideal_TDSValueMax"]):
            ideal_values["Ideal_TDSValueMax"] = plant.ideal_tdsvaluemax
        if plant.ideal_waterlevelmin is not None and (
                ideal_values["Ideal_WaterLevelMin"] is None or plant.ideal_waterlevelmin > ideal_values[
            "Ideal_WaterLevelMin"]):
            ideal_values["Ideal_WaterLevelMin"] = plant.ideal_waterlevelmin
        if plant.ideal_waterlevelmax is not None and (
                ideal_values["Ideal_WaterLevelMax"] is None or plant.ideal_waterlevelmax < ideal_values[
            "Ideal_WaterLevelMax"]):
            ideal_values["Ideal_WaterLevelMax"] = plant.ideal_waterlevelmax
        if plant.ideal_watertemperaturemin is not None and (
                ideal_values["Ideal_WaterTemperatureMin"] is None or plant.ideal_watertemperaturemin > ideal_values[
            "Ideal_WaterTemperatureMin"]):
            ideal_values["Ideal_WaterTemperatureMin"] = plant.ideal_watertemperaturemin
        if plant.ideal_watertemperaturemax is not None and (
                ideal_values["Ideal_WaterTemperatureMax"] is None or plant.ideal_watertemperaturemax < ideal_values[
            "Ideal_WaterTemperatureMax"]):
            ideal_values["Ideal_WaterTemperatureMax"] = plant.ideal_watertemperaturemax
        if plant.ideal_wateroxygenLevelmin_mg_l is not None and (
                ideal_values["Ideal_WaterOxygenLevelMin_mg_l"] is None or plant.ideal_wateroxygenLevelmin_mg_l >
                ideal_values["Ideal_WaterOxygenLevelMin_mg_l"]):
            ideal_values["Ideal_WaterOxygenLevelMin_mg_l"] = plant.ideal_wateroxygenLevelmin_mg_l
        if plant.ideal_wateroxygenLevelmax_mg_l is not None and (
                ideal_values["Ideal_WaterOxygenLevelMax_mg_l"] is None or plant.ideal_wateroxygenLevelmax_mg_l <
                ideal_values["Ideal_WaterOxygenLevelMax_mg_l"]):
            ideal_values["Ideal_WaterOxygenLevelMax_mg_l"] = plant.ideal_wateroxygenLevelmax_mg_l
        if plant.ideal_lightdurationmin is not None and (
                ideal_values["Ideal_LightDurationMin"] is None or plant.ideal_lightdurationmin > ideal_values[
            "Ideal_LightDurationMin"]):
            ideal_values["Ideal_LightDurationMin"] = plant.ideal_lightdurationmin
        if plant.ideal_lightdurationmax is not None and (
                ideal_values["Ideal_LightDurationMax"] is None or plant.ideal_lightdurationmax < ideal_values[
            "Ideal_LightDurationMax"]):
            ideal_values["Ideal_LightDurationMax"] = plant.ideal_lightdurationmax
        if plant.ideal_lightintensitymin_nm is not None and (
                ideal_values["Ideal_LightIntensityMin_nm"] is None or plant.ideal_lightintensitymin_nm > ideal_values[
            "Ideal_LightIntensityMin_nm"]):
            ideal_values["Ideal_LightIntensityMin_nm"] = plant.ideal_lightintensitymin_nm
        if plant.ideal_lightintensitymax_nm is not None and (
                ideal_values["Ideal_LightIntensityMax_nm"] is None or plant.ideal_lightintensitymax_nm < ideal_values[
            "Ideal_LightIntensityMax_nm"]):
            ideal_values["Ideal_LightIntensityMax_nm"] = plant.ideal_lightintensitymax_nm
        if plant.ideal_airoxygenlevelmin is not None and (
                ideal_values["Ideal_AirOxygenLevelMin"] is None or plant.ideal_airoxygenlevelmin > ideal_values[
            "Ideal_AirOxygenLevelMin"]):
            ideal_values["Ideal_AirOxygenLevelMin"] = plant.ideal_airoxygenlevelmin
        if plant.ideal_airoxygenlevelmax is not None and (
                ideal_values["Ideal_AirOxygenLevelMax"] is None or plant.ideal_airoxygenlevelmax < ideal_values[
            "Ideal_AirOxygenLevelMax"]):
            ideal_values["Ideal_AirOxygenLevelMax"] = plant.ideal_airoxygenlevelmax
        if plant.ideal_airco2levelmin is not None and (
                ideal_values["Ideal_AirCO2LevelMin"] is None or plant.ideal_airco2levelmin > ideal_values[
            "Ideal_AirCO2LevelMin"]):
            ideal_values["Ideal_AirCO2LevelMin"] = plant.ideal_airco2levelmin
        if plant.ideal_airco2levelmax is not None and (
                ideal_values["Ideal_AirCO2LevelMax"] is None or plant.ideal_airco2levelmax < ideal_values[
            "Ideal_AirCO2LevelMax"]):
            ideal_values["Ideal_AirCO2LevelMax"] = plant.ideal_airco2levelmax
        if plant.ideal_airtemperaturedaymin is not None and (
                ideal_values["Ideal_AirTemperatureDayMin"] is None or plant.ideal_airtemperaturedaymin > ideal_values[
            "Ideal_AirTemperatureDayMin"]):
            ideal_values["Ideal_AirTemperatureDayMin"] = plant.ideal_airtemperaturedaymin
        if plant.ideal_airtemperaturedaymax is not None and (
                ideal_values["Ideal_AirTemperatureDayMax"] is None or plant.ideal_airtemperaturedaymax < ideal_values[
            "Ideal_AirTemperatureDayMax"]):
            ideal_values["Ideal_AirTemperatureDayMax"] = plant.ideal_airtemperaturedaymax
        if plant.ideal_airtemperaturenightmin is not None and (
                ideal_values["Ideal_AirTemperatureNightMin"] is None or plant.ideal_airtemperaturenightmin >
                ideal_values["Ideal_AirTemperatureNightMin"]):
            ideal_values["Ideal_AirTemperatureNightMin"] = plant.ideal_airtemperaturenightmin
        if plant.ideal_airtemperaturenightmax is not None and (
                ideal_values["Ideal_AirTemperatureNightMax"] is None or plant.ideal_airtemperaturenightmax <
                ideal_values["Ideal_AirTemperatureNightMax"]):
            ideal_values["Ideal_AirTemperatureNightMax"] = plant.ideal_airtemperaturenightmax
        if plant.ideal_humiditymin is not None and (
                ideal_values["Ideal_HumidityMin"] is None or plant.ideal_humiditymin > ideal_values[
            "Ideal_HumidityMin"]):
            ideal_values["Ideal_HumidityMin"] = plant.ideal_humiditymin
        if plant.ideal_humiditymax is not None and (
                ideal_values["Ideal_HumidityMax"] is None or plant.ideal_humiditymax < ideal_values[
            "Ideal_HumidityMax"]):
            ideal_values["Ideal_HumidityMax"] = plant.ideal_humiditymax
        if plant.ideal_wn_nitrogen is not None and ideal_values["Ideal_WN_Nitrogen"] is None:
            ideal_values["Ideal_WN_Nitrogen"] = plant.ideal_wn_nitrogen
        if plant.ideal_wn_phosphor is not None and ideal_values["Ideal_WN_Phosphor"] is None:
            ideal_values["Ideal_WN_Phosphor"] = plant.ideal_wn_phosphor
        if plant.ideal_wn_potassium is not None and ideal_values["Ideal_WN_Potassium"] is None:
            ideal_values["Ideal_WN_Potassium"] = plant.ideal_wn_potassium
        if plant.ideal_wn_sulfur is not None and ideal_values["Ideal_WN_Sulfur"] is None:
            ideal_values["Ideal_WN_Sulfur"] = plant.ideal_wn_sulfur
        if plant.ideal_wn_calcium is not None and ideal_values["Ideal_WN_Calcium"] is None:
            ideal_values["Ideal_WN_Calcium"] = plant.ideal_wn_calcium
        if plant.ideal_wn_magnesium is not None and ideal_values["Ideal_WN_Magnesium"] is None:
            ideal_values["Ideal_WN_Magnesium"] = plant.ideal_wn_magnesium
        if plant.ideal_wn_iron is not None and ideal_values["Ideal_WN_Iron"] is None:
            ideal_values["Ideal_WN_Iron"] = plant.ideal_wn_iron
        if plant.ideal_wn_manganese is not None and ideal_values["Ideal_WN_Manganese"] is None:
            ideal_values["Ideal_WN_Manganese"] = plant.ideal_wn_manganese
        if plant.ideal_wn_boron is not None and ideal_values["Ideal_WN_Boron"] is None:
            ideal_values["Ideal_WN_Boron"] = plant.ideal_wn_boron
        if plant.ideal_wn_copper is not None and ideal_values["Ideal_WN_Copper"] is None:
            ideal_values["Ideal_WN_Copper"] = plant.ideal_wn_copper
        if plant.ideal_wn_zinc is not None and ideal_values["Ideal_WN_Zinc"] is None:
            ideal_values["Ideal_WN_Zinc"] = plant.ideal_wn_zinc
        if plant.ideal_wn_molybdenum is not None and ideal_values["Ideal_WN_Molybdenum"] is None:
            ideal_values["Ideal_WN_Molybdenum"] = plant.ideal_wn_molybdenum

    def calculate_avg_value(value_min, value_max, vorheriger_wert=None):
        if value_min is not None and value_max is not None:
            return (value_min + value_max) / 2
        elif value_min is not None:
            return value_min
        elif value_max is not None:
            return value_max
        else:
            return vorheriger_wert

    selected_system.phvalue = calculate_avg_value(ideal_values["Ideal_PHValueMin"], ideal_values["Ideal_PHValueMax"], selected_system.phvalue)
    selected_system.ecvalue = calculate_avg_value(ideal_values["Ideal_ECValueMin_mS_cm"],
                                                  ideal_values["Ideal_ECValueMax_mS_cm"], selected_system.ecvalue)
    selected_system.tdsvalue = calculate_avg_value(ideal_values["Ideal_TDSValueMin"], ideal_values["Ideal_TDSValueMax"], selected_system.tdsvalue)
    selected_system.waterlevel = calculate_avg_value(ideal_values["Ideal_WaterLevelMin"],
                                                     ideal_values["Ideal_WaterLevelMax"], selected_system.waterlevel)
    selected_system.watertemperature = calculate_avg_value(ideal_values["Ideal_WaterTemperatureMin"],
                                                           ideal_values["Ideal_WaterTemperatureMax"], selected_system.watertemperature)
    selected_system.wateroxygenlevel = calculate_avg_value(ideal_values["Ideal_WaterOxygenLevelMin_mg_l"],
                                                           ideal_values["Ideal_WaterOxygenLevelMax_mg_l"], selected_system.wateroxygenlevel)
    selected_system.lightduration = calculate_avg_value(ideal_values["Ideal_LightDurationMin"],
                                                        ideal_values["Ideal_LightDurationMax"], selected_system.lightduration)
    selected_system.lightintensity = calculate_avg_value(ideal_values["Ideal_LightIntensityMin_nm"],
                                                         ideal_values["Ideal_LightIntensityMax_nm"], selected_system.lightintensity)
    selected_system.airoxygenlevel = calculate_avg_value(ideal_values["Ideal_AirOxygenLevelMin"],
                                                         ideal_values["Ideal_AirOxygenLevelMax"], selected_system.airoxygenlevel)
    selected_system.airco2level = calculate_avg_value(ideal_values["Ideal_AirCO2LevelMin"],
                                                      ideal_values["Ideal_AirCO2LevelMax"], selected_system.airco2level)
    selected_system.airtemperatureday = calculate_avg_value(ideal_values["Ideal_AirTemperatureDayMin"],
                                                            ideal_values["Ideal_AirTemperatureDayMax"], selected_system.airtemperatureday)
    selected_system.airtemperaturenight = calculate_avg_value(ideal_values["Ideal_AirTemperatureNightMin"],
                                                              ideal_values["Ideal_AirTemperatureNightMax"], selected_system.airtemperaturenight)
    selected_system.humidity = calculate_avg_value(ideal_values["Ideal_HumidityMin"], ideal_values["Ideal_HumidityMax"], selected_system.humidity)
    selected_system.wn_nitrogen = ideal_values["Ideal_WN_Nitrogen"]
    selected_system.wn_phosphor = ideal_values["Ideal_WN_Phosphor"]
    selected_system.wn_potassium = ideal_values["Ideal_WN_Potassium"]
    selected_system.wn_sulfur = ideal_values["Ideal_WN_Sulfur"]
    selected_system.wn_calcium = ideal_values["Ideal_WN_Calcium"]
    selected_system.wn_magnesium = ideal_values["Ideal_WN_Magnesium"]
    selected_system.wn_iron = ideal_values["Ideal_WN_Iron"]
    selected_system.wn_manganese = ideal_values["Ideal_WN_Manganese"]
    selected_system.wn_boron = ideal_values["Ideal_WN_Boron"]
    selected_system.wn_copper = ideal_values["Ideal_WN_Copper"]
    selected_system.wn_zinc = ideal_values["Ideal_WN_Zinc"]
    selected_system.wn_molybdenum = ideal_values["Ideal_WN_Molybdenum"]
    selected_system.save()


def index(request):
    return render(request, 'index.html')


def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            return redirect('index')
        else:
            messages.info(request, 'Eingabe nicht korrekt')
            return redirect('login')

    else:
        return render(request, 'login.html')


def logout(request):
    auth.logout(request)
    return redirect('/')


def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        passwordwiederholen = request.POST['passwordwiederholen']
        vorname = request.POST['firstname']
        nachname = request.POST['lastname']

        if password == "":
            messages.info(request, 'Passwort ist ein Pflichtfeld')
            return redirect('signup')
        elif password == passwordwiederholen:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'Username bereits in Nutzung')
                return redirect('signup')
            if username == "":
                messages.info(request, 'Username ist ein Pflichtfeld')
                return redirect('signup')
            if email == "":
                messages.info(request, 'Email ist ein Pflichtfeld')
                return redirect('signup')
            if User.objects.filter(email=email).exists():
                messages.info(request, 'Email bereits in Nutzung')
                return redirect('signup')

            else:
                user = User.objects.create_user(username=username, email=email, password=password, first_name=vorname,
                                                last_name=nachname)
                user.save()
                return redirect('login')
        else:
            messages.info(request, 'Die Passwoerter stimmen nicht ueberein.')
            return redirect('signup')
    else:
        return render(request, 'signup.html')


@login_required
def dashboard(request):
    selected_greenhouse = request.GET.get('greenhouse')
    try:
        selected_greenhouse = int(selected_greenhouse)
    except (ValueError, TypeError):
        selected_greenhouse = None

    user_assignments = Greenhouseuserassignment.objects.filter(userid=request.user)
    greenhouses = [assignment.greenhouseid for assignment in user_assignments]
    noGreenhouse = False
    if len(greenhouses) == 0:
        greenhouses = ['None']
        noGreenhouse = True
    else:
        if selected_greenhouse is None:
            selected_greenhouse = Greenhouses.objects.get(greenhouseid=greenhouses[0].greenhouseid).greenhouseid

    # Abrufen aller Systeme, die mit der gegebenen Greenhouse ID übereinstimmen
    systems = Systems.objects.filter(greenhouseid=selected_greenhouse).values(
        'systemid', 'systemname', 'phvalue', 'ecvalue'
    )

    plants_anz = 0
    if systems is not None:
        # Speichern der Daten in einem Dictionary, wobei der Schlüssel die SystemID ist
        systems_data = {}
        for system_infos in systems:
            system_id = system_infos['systemid']
            systems_data[system_id] = {
                'SystemName': system_infos['systemname']
            }
            if system_infos['phvalue'] is not None:
                systems_data[system_id]['PHValue_Soll'] = float(system_infos['phvalue'])
            if system_infos['ecvalue'] is not None:
                systems_data[system_id]['ECValue_Soll'] = float(system_infos['ecvalue'])

            plantsInSystem = Systemsplantsassignment.objects.filter(systemid=system_id).count()
            systems_data[system_id]['plantsInSystem'] = plantsInSystem
            plants_anz += plantsInSystem

            lastest_measurements = get_latest_sensor_data_for_system(system_id)
            for measurement in lastest_measurements:
                if measurement[7] == 'PHValue':
                    systems_data[system_id]['PHValue_Ist'] = float(measurement[6])
                elif measurement[7] == 'ECValue':
                    systems_data[system_id]['ECValue_Ist'] = float(measurement[6])
    else:
        systems_data = None

    context = {
        'greenhouses': greenhouses,
        'add_new': True,  # Option, um ein neues Gewächshaus hinzuzufügen
        'noGreenhouse': noGreenhouse,
        'selected_greenhouse': selected_greenhouse,
        'systems_data': systems_data,
        'plants_anz': plants_anz
    }

    return render(request, 'dashboard.html', context)


@login_required
def select_greenhouse(request):
    selected_value = request.POST.get('greenhouse')
    if selected_value == 'add_new':
        # Logik zum Hinzufügen eines neuen Gewächshauses
        return HttpResponseRedirect('add_greenhouse')
    else:
        # Logik, um die Seite mit den Infos des ausgewählten Gewächshauses zu laden
        return HttpResponseRedirect(f'/dashboard?greenhouse={selected_value}')


@login_required
def add_greenhouse(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        location = request.POST.get('location')

        # Erstelle ein neues Gewächshausobjekt und speichere es in der Datenbank
        new_greenhouse = Greenhouses(name=name, location=location)
        new_greenhouse.save()

        # Verknüpfe das neue Gewächshaus mit dem User mittels rohem SQL
        with connection.cursor() as cursor:
            cursor.execute(
                "INSERT INTO GreenhouseUserAssignment (UserID, GreenhouseID) VALUES (%s, %s)",
                [request.user.id, new_greenhouse.greenhouseid]
            )

        # Leite den User zum Dashboard um
        return redirect('/dashboard')
    else:
        return render(request, 'add_greenhouse.html')


@login_required
def add_system(request):
    if request.method == 'POST':
        greenhouse_id = request.session.get('greenhouse_id')

        # Überprüfen Sie, ob die Greenhouse-ID existiert und dem angemeldeten User zugeordnet ist
        try:
            # Zuerst überprüfen wir, ob das Greenhouse existiert
            greenhouse_id = get_object_or_404(Greenhouses, pk=greenhouse_id)

            # Dann überprüfen wir die Zuweisung zum User
            user_assignment = Greenhouseuserassignment.objects.get(
                userid=request.user,
                greenhouseid=greenhouse_id
            )
        except Greenhouseuserassignment.DoesNotExist:
            # Wenn keine Zuweisung gefunden wird, werfen wir einen 404-Fehler
            raise Http404("Keine Zuweisung für den User mit dieser Greenhouse-ID gefunden.")

        name = request.POST.get('name')
        comments = request.POST.get('comments')
        readymadefertilizer = request.POST.get('readymadefertilizer')
        growthstagename = request.POST.get('growthstagename')
        growth_stage = get_object_or_404(Growthstages, growthstagename=growthstagename)

        # Erstelle ein neues Systemobjekt und speichere es in der Datenbank
        new_system = Systems(greenhouseid=greenhouse_id, systemname=name, comments=comments,
                             growthstagename=growth_stage, readymadefertilizer=readymadefertilizer)
        new_system.save()

        # Leite den User zum Dashboard um
        return redirect('/dashboard?greenhouse=' + str(greenhouse_id.greenhouseid))
    else:
        selected_greenhouse = request.GET.get('greenhouse')
        context = {
            'selected_greenhouse': selected_greenhouse
        }
        return render(request, 'add_system.html', context)


@login_required
def create_system(request):
    if request.method == 'POST':
        greenhouse_id = request.POST.get('greenhouse_id')
        if greenhouse_id is None:
            return redirect('/dashboard')
    elif request.session.get('greenhouse_id') is not None:
        greenhouse_id = request.session.get('greenhouse_id')
    else:
        # Leite den User zum Dashboard um
        return redirect('/dashboard')

    request.session['greenhouse_id'] = greenhouse_id
    growthstages_list = Growthstages.objects.all()

    context = {
        'growthstages_list': growthstages_list
    }

    # Leite den User zum add_system um
    return render(request, 'add_system.html', context)


@login_required
def system(request):
    selected_system_id = request.POST.get('system')
    greenhouse_id = request.POST.get('greenhouse_id')
    delete_plat_id = request.POST.get('delete_plantid')

    if greenhouse_id is None:
        return redirect('/dashboard')

    if selected_system_id == 'add_new':
        request.session['greenhouse_id'] = greenhouse_id
        return redirect('/create_system')
    else:
        try:
            selected_system_id = int(selected_system_id)
        except (ValueError, TypeError):
            return redirect('/dashboard')

    if selected_system_id is None:
        return redirect('/dashboard?greenhouse=' + str(greenhouse_id))

    # Überprüfen, ob das System dem User zugeordnet ist
    try:
        selected_system = Systems.objects.get(systemid=selected_system_id, greenhouseid=greenhouse_id)
    except Systems.DoesNotExist:
        return redirect('/dashboard')  # Wenn das System nicht existiert oder die Greenhouse-ID nicht übereinstimmt

    # Überprüfung der Zuordnung des Gewächshauses zum User
    try:
        user_assignment = Greenhouseuserassignment.objects.get(
            userid=request.user,
            greenhouseid=selected_system.greenhouseid
        )
    except Greenhouseuserassignment.DoesNotExist:
        return redirect('/dashboard')  # Wenn das Gewächshaus nicht dem User zugeordnet ist

    if delete_plat_id is not None:
        Systemsplantsassignment.objects.filter(systemid=selected_system_id, plantsid=delete_plat_id).delete()
        sytem_plants_query = Systemsplantsassignment.objects.filter(systemid=selected_system_id)
        plantsInSystem = []
        for plant in sytem_plants_query:
            plantsInSystem.append(plant.plantsid)
        calculate_System(selected_system, plantsInSystem)

    # überprüfen, ob Pflanzen in dem System existieren
    plants_request = Systemsplantsassignment.objects.filter(systemid=selected_system)
    plants = []
    for plant in plants_request:
        plants.append(plant.plantsid)

    if plants is not None:
        # Soll daten System abrufen
        System_data = Systems.objects.filter(systemid=selected_system_id).first()

        system_soll_data = {}
        for field in Systems._meta.fields:
            field_name = field.name
            if field_name not in ['systemid', 'greenhouseid', 'systemname', 'creationdate', 'changedate', 'comments',
                                  'growthstagename', 'readymadefertilizer']:
                value = getattr(System_data, field_name, None)
                # Wenn nicht none, speichern
                if value is not None:
                    system_soll_data[field_name] = [value]

        # get device ids
        device_ids = []
        for key, value in system_soll_data.items():
            if key == 'airtemperatureday' or key == 'airtemperaturenight':
                sensortype = Sensortypes.objects.filter(system_valuename='airtemperature').first()
            else:
                sensortype = Sensortypes.objects.filter(system_valuename=key).first()
            if sensortype is not None:
                # append list of [unit, difference_warning, difference_critical]
                system_soll_data[key].append(
                    [sensortype.unit, sensortype.difference_warning, sensortype.difference_critical])
                try:
                    system_soll_data[key].append(Devices.objects.filter(systemid=selected_system_id,
                                                                        sensortypeid=sensortype.sensortypeid).values(
                        'deviceid')[0]['deviceid'])
                except IndexError:
                    pass

        # Aktuelle Werte für System abrufen
        measurements_data = {}

        for key, value in system_soll_data.items():
            latest_measurement_data = None
            if len(value) > 2:
                with connection.cursor() as cursor:
                    cursor.execute('''SELECT Measurement
                                        From HistoryDeviceData
                                        inner join Devices on HistoryDeviceData.DeviceID = Devices.DeviceID
                                        inner join Systems on Devices.SystemID = Systems.SystemID
                                        inner join GreenhouseUserAssignment on Systems.GreenhouseID = GreenhouseUserAssignment.GreenhouseID
                                        inner join auth_user on GreenhouseUserAssignment.UserID = auth_user.id
                                        where auth_user.id = %s and Devices.DeviceID = %s
                                        order by Date desc, Time desc
                                        limit 1''', [request.user.id, value[-1]])
                    latest_measurement_data = cursor.fetchone()

            if latest_measurement_data is None:
                measurements_data[key] = {
                    'current_value': None,
                    'target_value': round(value[0], 2),
                    'difference': None,
                    'difference_link': 'img/status/nostatus.png',
                    'unit': value[1][0],
                    'device_id': None
                }
            else:
                latest_measurement = latest_measurement_data[0]
                difference = abs(latest_measurement - value[0])
                if difference > value[1][2]:
                    difference_link = 'img/status/critical.png'
                elif difference > value[1][1]:
                    difference_link = 'img/status/warning.png'
                else:
                    difference_link = 'img/status/ok.png'

                measurements_data[key] = {
                    'current_value': round(latest_measurement, 2),
                    'target_value': round(value[0], 2),
                    'difference': difference,
                    'difference_link': difference_link,
                    'unit': value[1][0],
                    'device_id': value[-1]
                }
    else:
        measurements_data = None

    growthstages_list = Growthstages.objects.all()

    context = {
        'selected_system': selected_system,
        'greenhouse_id': greenhouse_id,
        'measurements_data': measurements_data,
        'growthstages_list': growthstages_list,
        'plants': plants
    }

    return render(request, 'system.html', context)


def get_chart_data(request, device_id):
    # Holen der Daten basierend auf der device_id
    with connection.cursor() as cursor:
        cursor.execute('''SELECT
                                Date, AVG(Measurement) AS AverageMeasurement
                            FROM
                                HistoryDeviceData
                            WHERE
                                DeviceID = %s
                            GROUP BY
                                DeviceID,
                                Date
                            ORDER BY
                                DeviceID,
                                Date
                            LIMIT 30''', [device_id])
        result = cursor.fetchall()

        # Erstellen von Labels und Daten für das Diagramm
        labels = []
        data = []
        for row in result:
            labels.append(row[0])  # Datum
            data.append(float(row[1]))  # Durchschnittliche Messung, umwandeln in float für JSON-Kompatibilität

        # Verpacken der Daten für die JsonResponse
        chart_data = {
            'labels': labels,
            'datasets': [{
                'label': 'Durchschnittliche Messung',
                'data': data,
                'borderColor': 'rgb(75, 192, 192)',
                'tension': 0.1,
                'fill': False
            }]
        }

    return JsonResponse(chart_data)


@login_required
def edit_system(request):
    if request.method == 'POST':
        greenhouse_id = request.POST.get('greenhouse_id')
        system_id = request.POST.get('system_id')
        ready_made_fertilizer = request.POST.get('readymadefertilizer')
        growth_stage = request.POST.get('growthstagename')
        return redirect('/dashboard?greenhouse=' + str(greenhouse_id))

    return redirect('/dashboard')


@login_required
def add_plants(request):
    if request.method != 'POST':
        return redirect('/dashboard')

    system_id = request.POST.get('system_id')
    plant_id = request.POST.get('plant_id')

    # Überprüfen, ob das System dem User zugeordnet ist
    try:
        selected_system = Systems.objects.get(systemid=system_id)
        user_assignment = Greenhouseuserassignment.objects.get(
            userid=request.user,
            greenhouseid=selected_system.greenhouseid
        )
        plants_request = list(Systemsplantsassignment.objects.filter(systemid=selected_system).values('plantsid'))
        plantsInSystem = []
        for plant in plants_request:
            plantsInSystem.append(plant['plantsid'])
    except Greenhouseuserassignment.DoesNotExist:
        # Wenn keine Zuweisung gefunden wird, werfen wir einen 404-Fehler
        raise Http404("Keine Zuweisung für den User mit dieser Greenhouse-ID gefunden.")
    except Systems.DoesNotExist:
        return redirect('/dashboard')  # Wenn das System nicht existiert oder die Greenhouse-ID nicht übereinstimmt

    if plant_id is not None:
        new_plant = Plants.objects.get(plantsid=plant_id)
        plantsInSystem_objects = [new_plant]
        for plant_id in plantsInSystem:
            plantsInSystem_objects.append(Plants.objects.get(plantsid=plant_id))

        calculate_System(selected_system, plantsInSystem_objects)

        # Verknüpfe die neue Pflanze mit System mittels rohem SQL
        with connection.cursor() as cursor:
            cursor.execute(
                "INSERT INTO SystemsPlantsAssignment (SystemID, PlantsID) VALUES (%s, %s)",
                [system_id, new_plant.plantsid]
            )

        return_message = 'Pflanze erfolgreich hinzugefügt'
        context = {
            'new_plant': True,  # Option, um eine neue Pflanze hinzuzufügen
            'return_message': return_message
        }

        return redirect('/dashboard')
    else:
        plants = Plants.objects.all()
        plants_list = [plant for plant in plants if plant.plantsid not in plantsInSystem]

        context = {
            'new_plant': False,  # Option, um eine neue Pflanze hinzuzufügen
            'plants_list': plants_list,
            'selected_system': selected_system
        }

    return render(request, 'add_plants.html', context)


@login_required
def add_sensor(request):
    if request.method != 'POST':
        return redirect('/dashboard')

    system_id = request.POST.get('system_id')
    sensor_name = request.POST.get('sensor_name')
    sensor_soll = request.POST.get('target_value')

    # Überprüfen, ob das System dem User zugeordnet ist
    try:
        selected_system = Systems.objects.get(systemid=system_id)
        user_assignment = Greenhouseuserassignment.objects.get(
            userid=request.user,
            greenhouseid=selected_system.greenhouseid
        )

        System_data = Systems.objects.filter(systemid=system_id).first()
        available_sensors = []
        for field in Systems._meta.fields:
            field_name = field.name
            if field_name not in ['systemid', 'greenhouseid', 'systemname', 'creationdate', 'changedate', 'comments',
                                  'growthstagename', 'readymadefertilizer']:
                value = getattr(System_data, field_name, None)
                if value is None:
                    available_sensors.append(field_name)

    except Greenhouseuserassignment.DoesNotExist:
        # Wenn keine Zuweisung gefunden wird, werfen wir einen 404-Fehler
        raise Http404("Keine Zuweisung für den User mit dieser Greenhouse-ID gefunden.")
    except Systems.DoesNotExist:
        return redirect('/dashboard')  # Wenn das System nicht existiert oder die Greenhouse-ID nicht übereinstimmt

    if sensor_name is not None:
        # Stelle sicher, dass sensor_name ein gültiger Spaltenname ist, um SQL-Injection zu vermeiden
        valid_column_names = set(value.lower() for value in Sensortypes.objects.values_list('system_valuename', flat=True))
        if sensor_name.lower() in valid_column_names:
            sql_query = f"UPDATE Systems SET {sensor_name} = %s WHERE SystemID = %s"
            with connection.cursor() as cursor:
                cursor.execute(sql_query, [sensor_soll, system_id])

            return_message = 'Sensor konnte nicht hinzugefügt werden'
            context = {
                'new_sensor': False,  # Option, um eine neue Pflanze hinzuzufügen
                'return_message': return_message
            }
        else:
            return_message = 'Sensor erfolgreich hinzugefügt'
            context = {
                'new_sensor': True,  # Option, um eine neue Pflanze hinzuzufügen
                'return_message': return_message
            }

        return redirect('/dashboard')
    else:
        context = {
            'new_sensor': False,  # Option, um eine neue Pflanze hinzuzufügen
            'sensor_list': available_sensors,
            'selected_system': selected_system
        }

    return render(request, 'add_sensor.html', context)
