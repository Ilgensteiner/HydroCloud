from django.db import connection


def get_latest_sensor_data_for_system(system_id):
    with connection.cursor() as cursor:
        cursor.callproc('GetLatestSensorDataForSystem', [system_id])
        result = cursor.fetchall()
    return result

