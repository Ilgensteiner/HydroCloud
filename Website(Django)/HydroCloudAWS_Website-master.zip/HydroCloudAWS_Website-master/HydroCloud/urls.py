from django.urls import path
from . import views
from .views import blogView, postView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='index'),
    path('login', views.login, name='login'),
    path('accounts/login/', views.login, name='login'),
    path('logout', views.logout, name='logout'),
    path('signup', views.signup, name='signup'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('select_greenhouse', views.select_greenhouse, name='select_greenhouse'),
    path('add_greenhouse', views.add_greenhouse, name='add_greenhouse'),
    path('add_system', views.add_system, name='add_system'),
    path('create_system', views.create_system, name='create_system'),
    path('edit_system', views.edit_system, name='edit_system'),
    path('system', views.system, name='system'),
    path('get-chart-data/<int:device_id>/', views.get_chart_data, name='get_chart_data'),
    path('add_plants', views.add_plants, name='add_plants'),
    path('blog', blogView.as_view(), name='blog'),
    path('post/<int:pk>', postView.as_view(), name='post'),
    path('create_blog_post/', views.create_blog_post, name='create_blog_post'),
    path('api/create_blog_post/', views.create_blog_post_api, name='create_blog_post_api'),
    path('add_sensor', views.add_sensor, name='add_sensor'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
